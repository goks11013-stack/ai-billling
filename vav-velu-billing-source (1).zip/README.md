# V.A.V. Velu Crackers & Fireworks - AI Billing & Management System

A complete, production-grade billing, inventory, invoice generation, and AI-powered voice & slip order management system designed for **V.A.V. Velu Crackers & Fireworks**.

---

## 🌟 Key Features

1. **🎙️ AI Voice Continuous Billing**
   - Natural speech dictation in Tamil, English, and Tanglish (e.g. *"Bijili 10 box, 1000 wala 5 pieces, Chakkar big 2 packets"*).
   - Real-time continuous speech transcription and intelligent matching against the shop's product catalog.
   - Automatically populates quantities, discounts, and prices into new invoices.

2. **📸 Handwritten Slip OCR & WhatsApp Order Parser**
   - Upload photos of customer handwritten paper order slips or paste WhatsApp text orders.
   - Powered by Google Gemini 3.8 Flash to extract customer details and catalog items automatically.

3. **🧾 Billing, Invoicing & Printing**
   - Instant bill generation with support for Cash, UPI, and Credit payments.
   - Wholesale and Retail pricing tiers with customizable product discounts.
   - Thermal receipt printer formatting (58mm / 80mm) and high-resolution A4 PDF invoice generation.
   - One-click PDF download and direct thermal printing.

4. **🔄 Real-Time Multi-Device Cloud Sync**
   - Integrated with Firebase Firestore for real-time synchronization across all counters and phones.
   - Multi-tab support and offline local caching when internet connection is intermittent.
   - Role-based access control: Admin and Counter Staff with individual PIN codes and recovery keys.

5. **📦 Inventory & Product Catalog Management**
   - Pre-loaded with comprehensive fireworks catalog (Sparklers, Chakkars, Flower Pots, Rockets, Garlands, Atom Bombs, Fancy Novelties).
   - Sl.No indexing, category filters, stock tracking, and wholesale/retail price editing.
   - JSON export and full cloud database backup/restore.

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher

### 2. Installation
Extract the zip file to your preferred folder and install dependencies:
```bash
npm install
```

### 3. Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Open `.env` and set your Gemini API key (optional for AI voice parsing; manual billing works without it):
```env
PORT=3000
GEMINI_API_KEY=your_gemini_api_key_here
```

### 4. Running the Application
Start the development server:
```bash
npm run dev
```
Or run the production server:
```bash
npm start
```

Open your browser and navigate to:
```
http://localhost:3000
```

---

## 📁 Project Structure

```
├── server.js                   # Express server & Gemini AI order parsing API
├── index.html                  # Full Single-Page Application (UI, Firebase sync, Voice AI, PDF)
├── package.json                # Project dependencies & startup scripts
├── firebase-applet-config.json # Firebase configuration
├── firebase-blueprint.json     # Firestore collections schema & definitions
├── firestore.rules             # Firestore security rules
├── .env.example                # Sample environment variables
└── README.md                   # Project documentation & instructions
```

---

## 🔒 Default Security & Access

- **Admin Login**: Requires setting or entering the 4-digit Master PIN.
- **Counter Staff**: Can create bills and view catalog without administrative access.
- **PIN Recovery**: Accessible via secure recovery code stored in settings.

---

## 📄 License
Commercial proprietary software for **V.A.V. Velu Crackers & Fireworks**.
