import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

// Support JSON bodies up to 25MB for image slip uploads
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Serve static assets from project root
app.use(express.static(__dirname));

// Resolve valid GEMINI_API_KEY
let geminiKey = process.env.GEMINI_API_KEY;
if (!geminiKey || geminiKey.startsWith('MY_GEMINI')) {
  try {
    if (fs.existsSync(path.join(__dirname, '.env'))) {
      const lines = fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n');
      for (const line of lines) {
        const [k, ...v] = line.split('=');
        if (k && k.trim() === 'GEMINI_API_KEY' && v.length) {
          geminiKey = v.join('=').trim().replace(/^["']|["']$/g, '');
          process.env.GEMINI_API_KEY = geminiKey;
          break;
        }
      }
    }
  } catch (e) {
    console.warn('Could not read .env:', e);
  }
}

// Initialize Gemini SDK with resolved key
const ai = new GoogleGenAI({ apiKey: geminiKey });

// AI Order parsing endpoint (Slip OCR / WhatsApp text / Voice dictation)
app.post('/api/ai-parse-order', async (req, res) => {
  try {
    const { text, imageBase64, mimeType = 'image/jpeg', catalog = [] } = req.body;

    if (!text && !imageBase64) {
      return res.status(400).json({ error: 'Please provide an image slip or order text' });
    }

    const catalogList = Array.isArray(catalog) ? catalog.map(p => ({
      id: p.id,
      sno: p.sno,
      name: p.name,
      category: p.category,
      unit: p.unit,
      price: p.price
    })) : [];

    const prompt = `You are an expert billing assistant for "V.A.V. Velu Crackers & Fireworks".
Your task is to analyze an incoming customer order (from a handwritten paper slip photo, a WhatsApp message, or voice transcript) and match the requested fireworks items to the shop's product catalog.

=== SHOP CATALOG (${catalogList.length} products) ===
${JSON.stringify(catalogList, null, 2)}

=== INSTRUCTIONS ===
1. Extract customer name, phone number, and address if mentioned or written.
2. For each requested item in the order:
   - Identify the quantity requested (integer, minimum 1). If not stated, assume 1.
   - Match it to the BEST matching item in the SHOP CATALOG by product name or Sl.No (sno).
   - Tamil / Tanglish / phonetic variations should be understood (e.g., "Bijili" / "Bijli" / "பிஜிலி", "Chakkar" / "Chakra" / "சக்கரம்", "Flower pot" / "Poo thotti" / "பூந்தொட்டி", "Sparklers" / "Kambi mathappu" / "மத்தாப்பு", "1000 wala" / "Garland" / "சரவெடி", "Laxmi" / "Lakshmi vedi", "Hydro bomb" / "Atom bomb" / "வெடி", "Chorsa", "Rocket").
   - If a product matches a catalog item, set "productId" to that catalog item's exact "id", set "name" to that catalog item's name, set "adHoc" to false.
   - If an item is clearly requested but NOT found in the catalog, set "productId" to "", set "name" to the item's name, set "adHoc" to true, and suggest a reasonable unit (e.g. "Box", "Pkt", "Nos") and price (0 if unknown).
3. Provide a brief 1-sentence note summarizing what was recognized.

Respond ONLY with a JSON object adhering to this schema:
{
  "customerName": "string",
  "phone": "string",
  "address": "string",
  "items": [
    {
      "productId": "string or empty",
      "sno": "number or string",
      "name": "string",
      "qty": 1,
      "unit": "string",
      "price": 0,
      "adHoc": false
    }
  ],
  "summary": "string"
}`;

    const parts = [];
    if (imageBase64) {
      const cleanData = imageBase64.replace(/^data:[^;]+;base64,/, '');
      parts.push({
        inlineData: {
          mimeType: mimeType || 'image/jpeg',
          data: cleanData
        }
      });
    }
    if (text) {
      parts.push({
        text: `Customer order text / transcription:\n"${text}"`
      });
    }
    parts.push({ text: prompt });

    const modelsToTry = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
    let response = null;
    let lastError = null;

    for (const model of modelsToTry) {
      try {
        response = await ai.models.generateContent({
          model,
          contents: { parts },
          config: {
            responseMimeType: 'application/json'
          }
        });
        if (response && response.text) break;
      } catch (err) {
        lastError = err;
        console.warn(`Model ${model} failed:`, err.message);
      }
    }

    if (!response || !response.text) {
      throw lastError || new Error('No response from AI model');
    }

    const outputText = response.text || '{}';
    let parsed;
    try {
      parsed = JSON.parse(outputText);
    } catch (err) {
      const cleaned = outputText.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim();
      parsed = JSON.parse(cleaned);
    }

    res.json({ success: true, result: parsed });
  } catch (error) {
    console.error('Error in /api/ai-parse-order:', error);
    res.status(500).json({ error: error.message || 'AI order parsing failed' });
  }
});

// Direct download route for source code zip
app.get(['/api/download-zip', '/download-source', '/vav-velu-billing-source.zip'], (req, res) => {
  const zipPath = path.join(__dirname, 'vav-velu-billing-source.zip');
  res.download(zipPath, 'vav-velu-billing-source.zip', (err) => {
    if (err && !res.headersSent) {
      res.status(500).send('Could not download zip file');
    }
  });
});

// SPA fallback for any route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, HOST, () => {
  console.log(`V.A.V. Velu Billing server listening on http://${HOST}:${PORT}`);
});

